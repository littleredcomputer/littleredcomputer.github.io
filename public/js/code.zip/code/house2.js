let rs = require('readline-sync')

world = {
    driveway: {
        info: "You're on a gravel driveway in front of a lonely chalet.",
        items: ["rock"],
        out: ['garage']        
    },
    garage: {
        info: "The garage is pretty empty. You see a doorway",
        items: ["sword"],
        out: ['driveway', 'mudroom']
    },
    mudroom: {
        info: "In the Mud Room. You should probably take off your shoes.",
        items: ["50 rupees"],
        out: ['garage', 'livingroom']
    }
}

let where = 'driveway'
let my_items = []

// this is the "main loop" of the game
for(;;) {  // do the following things forever
    console.log(world[where].info)
    if (my_items.length > 0) console.log("You are holding", my_items)
    if (world[where].items.length > 0) console.log("You see", world[where].items, "here.")
    let action = rs.keyInSelect(['move', 'take', 'drop'])
    if (action == 0) {
        let choice = rs.keyInSelect(world[where].out);
        if (choice == -1) continue // out of the loop
        where = world[where].out[choice]    
    } else if (action == 1) {
        if (world[where].items.length == 0) { console.log("nothing there"); continue }
        let choice = rs.keyInSelect(world[where].items)
        if (choice == -1) continue
        my_items = my_items.concat(world[where].items.splice(choice, 1))
    } else if (action == 2) {
        if (my_items.length == 0) { console.log("nothing there"); continue }
        let choice = rs.keyInSelect(my_items)
        if (choice == -1) continue
        world[where].items = world[where].items.concat(my_items.splice(choice, 1))
    } else if (action == -1) break
}



