let rs = require('readline-sync')

world = {
    driveway: {
        info: "You're on a gravel driveway in front of a lonely chalet.",
        items: ["rock"],
        out: ['garage']        
    },
    garage: {
        info: "The garage is pretty empty. You see a doorway",
        items: ["sword"],
        out: ['driveway', 'mudroom']
    },
    mudroom: {
        info: "In the Mud Room. You should probably take off your shoes.",
        items: ["50 rupees"],
        out: ['garage', 'livingroom']
    }
}

let where = 'driveway'
let my_items = []

// this is the "main loop" of the game
for(;;) {  // do the following things forever
    console.log(world[where].info)
    let here = world[where];
    if (my_items.length > 0) console.log("You are holding", my_items)
    if (here.items.length > 0) console.log("You see", here.items, "here.")
    let action = rs.keyInSelect(['move', 'take', 'drop'])
    if (action == 0) {
        let choice = rs.keyInSelect(here.out);
        if (choice == -1) continue // out of the loop
        where = here.out[choice]    
    } else if (action == 1) {
        if (here.items.length == 0) { console.log("nothing there"); continue }
        let choice = rs.keyInSelect(here.items)
        if (choice == -1) continue
        my_items = my_items.concat(here.items.splice(choice, 1))
    } else if (action == 2) {
        if (my_items.length == 0) { console.log("nothing there"); continue }
        let choice = rs.keyInSelect(my_items)
        if (choice == -1) continue
        here.items = world[where].items.concat(my_items.splice(choice, 1))
    } else if (action == -1) break
}



