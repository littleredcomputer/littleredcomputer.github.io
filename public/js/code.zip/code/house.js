let rs = require('readline-sync')

world = {
    driveway: {
        info: "You're on a gravel driveway in front of a lonely chalet.",
        out: ['garage']        
    },
    garage: {
        info: "The garage is pretty empty. You see a doorway",
        out: ['driveway', 'mudroom']
    },
    mudroom: {
        info: "In the Mud Room. You should probably take off your shoes.",
        out: ['garage', 'livingroom']
    }
}

let where = 'driveway'

// this is the "main loop" of the game
for(;;) {  // do the following things forever
    console.log(world[where].info)
    let choice = rs.keyInSelect(world[where].out);
    if (choice == -1) break // out of the loop
    where = world[where].out[choice]
}


// did you notice we mention world[where] three times above?
// that's an opportunity for a new variable.
