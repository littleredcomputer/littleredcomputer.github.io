let rs = require('readline-sync')

let world = {
    driveway: {
        info: "You're on a gravel driveway in front of a lonely chalet.",
        items: ["rock"],
        out: ['garage']        
    },
    garage: {
        info: "The garage is pretty empty. You see a doorway",
        items: ["sword"],
        out: ['driveway', 'mudroom']
    },
    mudroom: {
        info: "In the Mud Room. You should probably take off your shoes.",
        items: ["50 rupees"],
        out: ['garage', 'livingroom']
    }
}

let where = 'driveway'
let my_items = []

// offer the user the choice to move an item from the "from" basket
// to the "to" basket. Notice how we have handled the two "edge cases:"
// (1) Nothing there, and (2) User chooses nothing after all.
let moveItem = function(from, to) {
    if (from.length == 0) { console.log("nothing there"); return }
    let choice = rs.keyInSelect(from)
    if (choice == -1) return
    to.push(from.splice(choice, 1)[0])
}

// this is the "main loop" of the game
for(;;) {  // do the following things forever
    let here = world[where];
    console.log(here.info)
    if (my_items.length > 0) console.log("You are holding", my_items)
    if (here.items.length > 0) console.log("You see", here.items, "here.")
    let action = rs.keyInSelect(['move', 'take', 'drop'])
    if (action == 0) {
        let choice = rs.keyInSelect(here.out);
        if (choice == -1) continue // out of the loop
        where = here.out[choice]    
    } else if (action == 1) {
        moveItem(here.items, my_items)
    } else if (action == 2) {
        moveItem(my_items, here.items)
    } else if (action == -1) break
}



