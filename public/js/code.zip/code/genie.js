let makeGenie = function() {
    let wishes = 3;
    return {
        wishFor: function(thing) {
            if (wishes > 0) {
                console.log("I grant your wish for " + thing)
                wishes = wishes - 1
            }
            else console.log("You have run out of wishes, so you will have to live without " + thing)
        }
    }
}

let G = makeGenie()

G.wishFor('wealth')
G.wishFor('happiness')
G.wishFor('lambo')
G.wishFor('world peace')
G.wishFor('more wishes')

